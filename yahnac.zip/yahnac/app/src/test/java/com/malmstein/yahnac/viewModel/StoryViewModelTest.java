package com.malmstein.yahnac.viewModel;

import com.malmstein.yahnac.model.Story;

import org.junit.Before;

public class StoryViewModelTest {

    private Story story;

    @Before
    public void setUp() {

    }
}
