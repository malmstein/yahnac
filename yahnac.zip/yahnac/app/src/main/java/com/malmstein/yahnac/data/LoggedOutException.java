package com.malmstein.yahnac.data;

public class LoggedOutException extends Exception {
}
