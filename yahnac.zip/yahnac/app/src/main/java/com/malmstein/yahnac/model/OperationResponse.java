package com.malmstein.yahnac.model;

public enum OperationResponse {

    SUCCESS,
    FAILURE,
    LOGIN_EXPIRED

}
