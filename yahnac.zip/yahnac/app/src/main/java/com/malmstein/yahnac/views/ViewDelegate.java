package com.malmstein.yahnac.views;

public interface ViewDelegate {

    boolean isReadyForPull();

}
