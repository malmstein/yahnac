package com.malmstein.yahnac.comments;

import com.malmstein.yahnac.model.Story;

public interface CommentsListener {

    void onBookmarkClicked(Story story);
}
